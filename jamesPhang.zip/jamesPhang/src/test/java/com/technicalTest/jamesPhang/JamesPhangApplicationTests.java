package com.technicalTest.jamesPhang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JamesPhangApplicationTests {

	@Test
	void contextLoads() {
	}

}
