package com.technicalTest.jamesPhang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JamesPhangApplication {

	public static void main(String[] args) {
		SpringApplication.run(JamesPhangApplication.class, args);
	}

}
